@echo off
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

set "SCRIPT=%~dp0apply_beef_tudou_patch.py"
set "MANIFEST=%~dp0patch-manifest.json"
if not exist "%SCRIPT%" goto MISS
if not exist "%MANIFEST%" goto MISS

where py >nul 2>nul
if %errorlevel%==0 (set "PYEXE=py -3") else (set "PYEXE=python")

echo Applying BeefTV Tudou patch...
echo After success, you can delete this folder.
echo.
%PYEXE% "%SCRIPT%"
set "ERR=%ERRORLEVEL%"
echo.
if not "%ERR%"=="0" (
  echo [ERROR] Patch failed, code %ERR%
) else (
  echo [OK] Patch applied.
  echo Restart the backend to take effect, then refresh the canvas page.
)
echo.
pause
exit /b %ERR%

:MISS
echo [ERROR] Missing patch files in this folder.
echo Need:
echo   apply_beef_tudou_patch.py
echo   patch-manifest.json
echo   this bat/command
echo Current folder: %CD%
echo.
pause
exit /b 1
