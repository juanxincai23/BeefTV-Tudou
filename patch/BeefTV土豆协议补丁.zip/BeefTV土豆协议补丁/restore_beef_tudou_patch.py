# -*- coding: utf-8 -*-
"""BeefTV 土豆协议补丁 - 一键还原（双击 一键还原BeefTV补丁.bat / .command 运行）

把补丁覆盖过的文件还原到打补丁前的状态：
- 在 <项目>/.local/backup/ 下找最新的 *-pre-tudou-patch 备份（也可用命令行参数指定某个备份目录）；
- 还原前先把当前状态另存为 *-pre-restore 备份（还原本身也可再回退）；
- 补丁新增的文件（当时没有备份）会被删除，并在输出中逐条列出。
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from datetime import datetime

MARKERS = ("backend/internal/app", "web/src", "plugin-packages")


def configure_stdio():
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
            sys.stderr.reconfigure(encoding="utf-8")
        except Exception:
            pass


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_project_root(path):
    if not path or not os.path.isdir(path):
        return False
    for marker in MARKERS:
        if not os.path.isdir(os.path.join(path, *marker.split("/"))):
            return False
    return os.path.isfile(os.path.join(path, "AGENTS.md"))


def find_project_root(start_path):
    path = os.path.abspath(start_path)
    if os.path.isfile(path):
        path = os.path.dirname(path)
    for _ in range(8):
        if is_project_root(path):
            return path
        parent = os.path.dirname(path)
        if parent == path:
            break
        path = parent
    return ""


def load_manifest(tools_dir):
    manifest_path = os.path.join(tools_dir, "patch-manifest.json")
    if not os.path.isfile(manifest_path):
        return None
    with open(manifest_path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def find_backups(root):
    backup_root = os.path.join(root, ".local", "backup")
    if not os.path.isdir(backup_root):
        return []
    items = []
    for name in sorted(os.listdir(backup_root)):
        if name.endswith("-pre-tudou-patch") and os.path.isdir(os.path.join(backup_root, name)):
            items.append(os.path.join(backup_root, name))
    return items


def main():
    configure_stdio()
    here = os.path.abspath(__file__)
    tools_dir = os.path.dirname(here)
    root = find_project_root(tools_dir) or find_project_root(os.getcwd())
    if not root:
        print("没有找到 BeefTV 项目根目录（需要能看到 backend、web、plugin-packages 文件夹）。")
        print("请把本脚本放到项目根目录（或补丁文件夹内）后再双击。")
        return 1

    manifest = load_manifest(tools_dir)
    if manifest is None:
        print("[警告] 未找到 patch-manifest.json：只能还原备份目录里已有的文件，")
        print("        补丁新增的文件无法识别，请手动检查。")

    backups = find_backups(root)
    chosen = ""
    if len(sys.argv) > 1 and sys.argv[1].strip():
        candidate = os.path.abspath(sys.argv[1])
        if os.path.isdir(candidate):
            chosen = candidate
        else:
            print("[错误] 指定的备份目录不存在：" + candidate)
            return 1
    elif backups:
        chosen = backups[-1]
    if not chosen:
        print("没有找到任何 *-pre-tudou-patch 备份，无法还原。")
        print("备份目录应在：" + os.path.join(root, ".local", "backup"))
        return 1

    print("=" * 52)
    print(" BeefTV 土豆协议补丁 - 还原")
    print("=" * 52)
    print("项目目录：" + root)
    print("使用备份：" + chosen)
    if len(backups) > 1:
        print("（共找到 " + str(len(backups)) + " 个补丁备份，已选最新的一个；")
        print("  如需指定其他备份：python restore_beef_tudou_patch.py <备份目录>）")
    print()

    # 还原前先保存当前状态，保证还原本身可再回退
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    safety_root = os.path.join(root, ".local", "backup", stamp + "-pre-restore")
    entries = (manifest or {}).get("files") or []
    restored = 0
    deleted = 0
    kept = 0

    if entries:
        for entry in entries:
            target = os.path.join(root, entry["target"].replace("/", os.sep))
            if os.path.isfile(target):
                safety_file = os.path.join(safety_root, entry["target"].replace("/", os.sep))
                os.makedirs(os.path.dirname(safety_file), exist_ok=True)
                shutil.copy2(target, safety_file)
        print("已把当前状态备份到：" + safety_root)
        print()

        for entry in entries:
            target = os.path.join(root, entry["target"].replace("/", os.sep))
            backup_file = os.path.join(chosen, entry["target"].replace("/", os.sep))
            if os.path.isfile(backup_file):
                os.makedirs(os.path.dirname(target), exist_ok=True)
                shutil.copy2(backup_file, target)
                restored += 1
                print("  [还原] " + entry["target"])
            elif os.path.isfile(target):
                os.remove(target)
                deleted += 1
                print("  [删除] " + entry["target"] + "（补丁新增的文件）")
            else:
                kept += 1
    else:
        # 没有清单：只按备份内容还原
        for dirpath, _dirs, files in os.walk(chosen):
            for fn in files:
                src = os.path.join(dirpath, fn)
                rel = os.path.relpath(src, chosen)
                target = os.path.join(root, rel)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                shutil.copy2(src, target)
                restored += 1
                print("  [还原] " + rel.replace(os.sep, "/"))

    print()
    print("还原完成：还原 " + str(restored) + " 个文件，删除 " + str(deleted) + " 个补丁新增文件。")
    print()
    print("-" * 52)
    print("请重启后端（还原后 Go 代码回到旧版本），前端页面刷新一次。")
    print("如需再次打补丁：运行补丁文件夹里的 一键打BeefTV土豆补丁.bat。")
    print("本次还原前的状态已备份在：" + safety_root)
    print("-" * 52)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(1)
    except Exception as exc:
        print("还原失败：" + str(exc))
        raise SystemExit(1)
