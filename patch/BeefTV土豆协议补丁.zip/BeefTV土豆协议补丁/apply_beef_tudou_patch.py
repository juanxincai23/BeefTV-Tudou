# -*- coding: utf-8 -*-
"""BeefTV 土豆协议补丁 - 一键应用脚本（双击 一键打BeefTV土豆补丁.bat / .command 运行）

把补丁包 files/ 内的文件覆盖到 BeefTV 项目目录：
- 自动向上查找项目根目录（包含 backend、web、plugin-packages 的目录）；
- 应用前校验每个补丁文件的 sha256（损坏会中止）；
- 只把"确实会被覆盖"的现有文件备份到 <项目>/.local/backup/<时间戳>-pre-tudou-patch/；
- 一键启动脚本会释放到项目根目录；幂等：已是补丁版本的文件跳过并如实报告；
- 预置「土豆API」渠道（全部模型已配好，API Key 留空），已存在同源渠道时跳过。
不写入任何密钥，不修改数据库。
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from datetime import datetime

MARKERS = ("backend/internal/app", "web/src", "plugin-packages")

TUDOU_CHANNEL_JSON = r'''{
  "apiFormat": "openai",
  "apiKey": "",
  "baseUrl": "https://api.ai-tudou.net",
  "enabled": true,
  "headers": [],
  "id": "tudou",
  "modelProfiles": [
    {
      "capability": "image",
      "model": "gemini-3.1-flash-image-preview",
      "protocol": "tudou-image-gemini"
    },
    {
      "capability": "text",
      "model": "gemini-3.1-pro-preview",
      "protocol": "chat-completion"
    },
    {
      "capability": "image",
      "model": "gpt-image-2-pro",
      "protocol": "tudou-image-sync"
    },
    {
      "capability": "image",
      "model": "gpt-image-2.5-flare-async",
      "protocol": "tudou-image"
    },
    {
      "capability": "image",
      "model": "gpt-image-2.5-sunburst",
      "protocol": "tudou-image-sync"
    },
    {
      "capability": "image",
      "model": "gpt-image-2.5-sunburst-async",
      "protocol": "tudou-image"
    },
    {
      "capability": "image",
      "model": "seedream-5.0-pro",
      "protocol": "tudou-image"
    },
    {
      "capability": "video",
      "model": "wan3.0-video",
      "protocol": "tudou-video-wan"
    },
    {
      "capability": "image",
      "capabilityConfig": {
        "image": {
          "maxOutputs": 15,
          "outputFormat": {
            "supported": false
          },
          "quality": {
            "default": "low",
            "supported": true,
            "values": [
              "low",
              "medium",
              "high",
              "xhigh",
              "max"
            ]
          },
          "references": {
            "maskSupported": false,
            "maxImageBytes": 31457280,
            "maxImages": 9,
            "promptMaxChars": 32000
          },
          "responseFormat": {
            "supported": false
          },
          "size": {
            "allowCustom": true,
            "default": "1:1",
            "parameter": "aspect_ratio",
            "values": [
              "1:1",
              "3:2",
              "2:3",
              "4:3",
              "3:4",
              "5:4",
              "4:5",
              "16:9",
              "9:16",
              "2:1",
              "1:2",
              "3:1",
              "1:3",
              "21:9",
              "9:21"
            ]
          },
          "transparentBackground": {
            "default": false,
            "supported": false
          }
        },
        "text": {
          "references": {
            "maxImageBytes": 0,
            "maxImages": 0,
            "maxVideoBytes": 0,
            "maxVideos": 0,
            "promptMaxChars": 32000
          },
          "streaming": true
        },
        "version": 1,
        "video": {
          "defaultOperation": "text_to_video",
          "defaultRatio": "16:9",
          "defaultResolution": "720p",
          "duration": {
            "default": 6,
            "max": 15,
            "min": 1,
            "selection": "range",
            "step": 1
          },
          "generateAudio": {
            "default": false,
            "supported": false
          },
          "operations": [
            "text_to_video",
            "image_to_video"
          ],
          "ratios": [
            "16:9",
            "9:16",
            "1:1",
            "4:3",
            "3:4",
            "21:9"
          ],
          "references": {
            "maxAudioBytes": 0,
            "maxAudioDurationSeconds": 0,
            "maxAudios": 0,
            "maxImageBytes": 31457280,
            "maxImages": 9,
            "maxVideoBytes": 0,
            "maxVideoDurationSeconds": 0,
            "maxVideos": 0,
            "minImages": 0,
            "promptMaxChars": 8000
          },
          "resolutions": [
            "480p",
            "720p",
            "1080p",
            "1440p",
            "2160p"
          ],
          "watermark": {
            "default": false,
            "supported": false
          }
        }
      },
      "model": "gpt-image-2.5-flare",
      "protocol": "tudou-image-sync"
    },
    {
      "capability": "image",
      "capabilityConfig": {
        "image": {
          "maxOutputs": 15,
          "outputFormat": {
            "supported": true
          },
          "quality": {
            "default": "auto",
            "supported": true,
            "values": [
              "auto",
              "low",
              "medium",
              "high"
            ]
          },
          "references": {
            "maskSupported": true,
            "maxImageBytes": 31457280,
            "maxImages": 16,
            "promptMaxChars": 32000
          },
          "responseFormat": {
            "supported": true
          },
          "size": {
            "allowCustom": true,
            "default": "1:1",
            "parameter": "size",
            "values": [
              "auto",
              "1:1",
              "3:2",
              "2:3",
              "4:3",
              "3:4",
              "16:9",
              "21:9",
              "9:16",
              "1024x1024",
              "1360x1024",
              "1024x1360",
              "1536x1024",
              "1024x1536",
              "1024x1280",
              "1280x1024",
              "2048x878",
              "1824x1024",
              "1024x1824",
              "2048x2048",
              "2304x1728",
              "1728x2304",
              "2496x1664",
              "1664x2496",
              "1792x2240",
              "2240x1792",
              "3136x1344",
              "2752x1536",
              "1536x2752",
              "2880x2880",
              "3264x2448",
              "2448x3264",
              "3504x2336",
              "2336x3504",
              "2560x3200",
              "3200x2560",
              "3808x1632",
              "3840x2160",
              "2160x3840"
            ]
          },
          "transparentBackground": {
            "default": false,
            "supported": true
          }
        },
        "text": {
          "references": {
            "maxImageBytes": 0,
            "maxImages": 0,
            "maxVideoBytes": 0,
            "maxVideos": 0,
            "promptMaxChars": 32000
          },
          "streaming": true
        },
        "version": 1,
        "video": {
          "defaultOperation": "text_to_video",
          "defaultRatio": "16:9",
          "defaultResolution": "720p",
          "duration": {
            "default": 6,
            "max": 15,
            "min": 1,
            "selection": "range",
            "step": 1
          },
          "generateAudio": {
            "default": false,
            "supported": false
          },
          "operations": [
            "text_to_video",
            "image_to_video"
          ],
          "ratios": [
            "16:9",
            "9:16",
            "1:1",
            "4:3",
            "3:4",
            "21:9"
          ],
          "references": {
            "maxAudioBytes": 0,
            "maxAudioDurationSeconds": 0,
            "maxAudios": 0,
            "maxImageBytes": 31457280,
            "maxImages": 9,
            "maxVideoBytes": 0,
            "maxVideoDurationSeconds": 0,
            "maxVideos": 0,
            "minImages": 0,
            "promptMaxChars": 8000
          },
          "resolutions": [
            "480p",
            "720p",
            "1080p",
            "1440p",
            "2160p"
          ],
          "watermark": {
            "default": false,
            "supported": false
          }
        }
      },
      "model": "gpt-image-2-all",
      "protocol": "tudou-image"
    },
    {
      "capability": "image",
      "capabilityConfig": {
        "image": {
          "maxOutputs": 15,
          "outputFormat": {
            "supported": false
          },
          "quality": {
            "default": "1k",
            "supported": true,
            "values": [
              "1k",
              "2k",
              "4k"
            ]
          },
          "references": {
            "maskSupported": false,
            "maxImageBytes": 31457280,
            "maxImages": 9,
            "promptMaxChars": 32000
          },
          "responseFormat": {
            "supported": false
          },
          "size": {
            "allowCustom": true,
            "default": "1024x1024",
            "parameter": "size",
            "presets": [
              {
                "height": 1024,
                "ratio": "1:1",
                "size": "1024x1024",
                "tier": "1k",
                "width": 1024
              },
              {
                "height": 1024,
                "ratio": "16:9",
                "size": "1824x1024",
                "tier": "1k",
                "width": 1824
              },
              {
                "height": 1824,
                "ratio": "9:16",
                "size": "1024x1824",
                "tier": "1k",
                "width": 1024
              },
              {
                "height": 1024,
                "ratio": "4:3",
                "size": "1360x1024",
                "tier": "1k",
                "width": 1360
              },
              {
                "height": 1360,
                "ratio": "3:4",
                "size": "1024x1360",
                "tier": "1k",
                "width": 1024
              },
              {
                "height": 1024,
                "ratio": "3:2",
                "size": "1536x1024",
                "tier": "1k",
                "width": 1536
              },
              {
                "height": 1536,
                "ratio": "2:3",
                "size": "1024x1536",
                "tier": "1k",
                "width": 1024
              },
              {
                "height": 1280,
                "ratio": "4:5",
                "size": "1024x1280",
                "tier": "1k",
                "width": 1024
              },
              {
                "height": 1024,
                "ratio": "5:4",
                "size": "1280x1024",
                "tier": "1k",
                "width": 1280
              },
              {
                "height": 878,
                "ratio": "21:9",
                "size": "2048x878",
                "tier": "1k",
                "width": 2048
              },
              {
                "height": 2048,
                "ratio": "1:1",
                "size": "2048x2048",
                "tier": "2k",
                "width": 2048
              },
              {
                "height": 1536,
                "ratio": "16:9",
                "size": "2752x1536",
                "tier": "2k",
                "width": 2752
              },
              {
                "height": 2752,
                "ratio": "9:16",
                "size": "1536x2752",
                "tier": "2k",
                "width": 1536
              },
              {
                "height": 1728,
                "ratio": "4:3",
                "size": "2304x1728",
                "tier": "2k",
                "width": 2304
              },
              {
                "height": 2304,
                "ratio": "3:4",
                "size": "1728x2304",
                "tier": "2k",
                "width": 1728
              },
              {
                "height": 1664,
                "ratio": "3:2",
                "size": "2496x1664",
                "tier": "2k",
                "width": 2496
              },
              {
                "height": 2496,
                "ratio": "2:3",
                "size": "1664x2496",
                "tier": "2k",
                "width": 1664
              },
              {
                "height": 2240,
                "ratio": "4:5",
                "size": "1792x2240",
                "tier": "2k",
                "width": 1792
              },
              {
                "height": 1792,
                "ratio": "5:4",
                "size": "2240x1792",
                "tier": "2k",
                "width": 2240
              },
              {
                "height": 1344,
                "ratio": "21:9",
                "size": "3136x1344",
                "tier": "2k",
                "width": 3136
              },
              {
                "height": 2880,
                "ratio": "1:1",
                "size": "2880x2880",
                "tier": "4k",
                "width": 2880
              },
              {
                "height": 2160,
                "ratio": "16:9",
                "size": "3840x2160",
                "tier": "4k",
                "width": 3840
              },
              {
                "height": 3840,
                "ratio": "9:16",
                "size": "2160x3840",
                "tier": "4k",
                "width": 2160
              },
              {
                "height": 2448,
                "ratio": "4:3",
                "size": "3264x2448",
                "tier": "4k",
                "width": 3264
              },
              {
                "height": 3264,
                "ratio": "3:4",
                "size": "2448x3264",
                "tier": "4k",
                "width": 2448
              },
              {
                "height": 2336,
                "ratio": "3:2",
                "size": "3504x2336",
                "tier": "4k",
                "width": 3504
              },
              {
                "height": 3504,
                "ratio": "2:3",
                "size": "2336x3504",
                "tier": "4k",
                "width": 2336
              },
              {
                "height": 3200,
                "ratio": "4:5",
                "size": "2560x3200",
                "tier": "4k",
                "width": 2560
              },
              {
                "height": 2560,
                "ratio": "5:4",
                "size": "3200x2560",
                "tier": "4k",
                "width": 3200
              },
              {
                "height": 1632,
                "ratio": "21:9",
                "size": "3808x1632",
                "tier": "4k",
                "width": 3808
              }
            ],
            "values": [
              "1024x1024",
              "1824x1024",
              "1024x1824",
              "1360x1024",
              "1024x1360",
              "1536x1024",
              "1024x1536",
              "1024x1280",
              "1280x1024",
              "2048x878",
              "2048x2048",
              "2752x1536",
              "1536x2752",
              "2304x1728",
              "1728x2304",
              "2496x1664",
              "1664x2496",
              "1792x2240",
              "2240x1792",
              "3136x1344",
              "2880x2880",
              "3840x2160",
              "2160x3840",
              "3264x2448",
              "2448x3264",
              "3504x2336",
              "2336x3504",
              "2560x3200",
              "3200x2560",
              "3808x1632"
            ]
          },
          "transparentBackground": {
            "default": false,
            "supported": false
          }
        },
        "version": 1
      },
      "model": "gemini-3-pro-image-preview",
      "protocol": "tudou-image-gemini"
    }
  ],
  "models": [
    "gemini-3-pro-image-preview",
    "gemini-3.1-flash-image-preview",
    "gemini-3.1-pro-preview",
    "gpt-image-2-all",
    "gpt-image-2-pro",
    "gpt-image-2.5-flare",
    "gpt-image-2.5-flare-async",
    "gpt-image-2.5-sunburst",
    "gpt-image-2.5-sunburst-async",
    "seedream-5.0-pro",
    "wan3.0-video"
  ],
  "name": "土豆API",
  "pinned": false,
  "scope": "user",
  "secretKey": "",
  "sortOrder": 10
}'''


def configure_stdio():
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
            sys.stderr.reconfigure(encoding="utf-8")
        except Exception:
            pass


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_project_root(path):
    if not path or not os.path.isdir(path):
        return False
    for marker in MARKERS:
        if not os.path.isdir(os.path.join(path, *marker.split("/"))):
            return False
    return os.path.isfile(os.path.join(path, "AGENTS.md"))


def find_project_root(start_path):
    path = os.path.abspath(start_path)
    if os.path.isfile(path):
        path = os.path.dirname(path)
    for _ in range(8):
        if is_project_root(path):
            return path
        parent = os.path.dirname(path)
        if parent == path:
            break
        path = parent
    return ""


def is_tudou_channel(channel):
    if not isinstance(channel, dict):
        return False
    if str(channel.get("id", "")).strip().lower() == "tudou":
        return True
    if "土豆" in str(channel.get("name", "")):
        return True
    if "ai-tudou" in str(channel.get("baseUrl", "")):
        return True
    profiles = channel.get("modelProfiles")
    if isinstance(profiles, list):
        for profile in profiles:
            if isinstance(profile, dict) and str(profile.get("protocol", "")).startswith("tudou-"):
                return True
    return False


def write_json(path, value):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def ensure_tudou_channel(root, stamp):
    """预置土豆渠道：新建或合并进本地模型配置，密钥留空；已存在同源渠道则跳过。"""
    data_dir = os.path.join(root, ".local", "project-workbench-debug")
    config_path = os.path.join(data_dir, "local-model-config.json")
    template = json.loads(TUDOU_CHANNEL_JSON)
    print()
    if not os.path.isfile(config_path):
        os.makedirs(data_dir, exist_ok=True)
        write_json(config_path, {
            "schemaVersion": 1,
            "revision": 0,
            "presetVersions": {"beefapi": 1},
            "config": {"channels": [template]},
        })
        print("已创建本地模型配置，并预置「土豆API」渠道（全部模型已配好，API Key 留空）。")
        print("  配置文件：" + config_path)
        return "created"

    try:
        with open(config_path, "r", encoding="utf-8-sig") as f:
            document = json.load(f)
    except Exception as exc:
        print("[警告] 本地模型配置无法解析（" + str(exc) + "），跳过渠道预置。")
        return "skipped"

    if isinstance(document, dict) and "schemaVersion" in document:
        config = document.get("config")
        revision = document.get("revision", 0)
        preset_versions = document.get("presetVersions") or {"beefapi": 1}
    else:
        config = document
        revision = 0
        preset_versions = {"beefapi": 1}
    if not isinstance(config, dict):
        print("[警告] 本地模型配置格式无法识别，跳过渠道预置。")
        return "skipped"

    channels = config.get("channels")
    if not isinstance(channels, list):
        channels = []
    if any(is_tudou_channel(c) for c in channels):
        print("检测到已存在土豆渠道，跳过预置（不改动你现有的渠道配置）。")
        return "exists"

    channels.append(template)
    config["channels"] = channels
    backup_path = config_path + ".bak-pre-tudou-" + stamp
    shutil.copy2(config_path, backup_path)
    next_revision = revision + 1 if isinstance(revision, int) else 1
    write_json(config_path, {
        "schemaVersion": 1,
        "revision": next_revision,
        "presetVersions": preset_versions,
        "config": config,
    })
    print("已在本地模型配置中预置「土豆API」渠道（全部模型已配好，API Key 留空）。")
    print("  配置文件：" + config_path)
    print("  原文件备份：" + backup_path)
    return "added"


def main():
    configure_stdio()
    here = os.path.abspath(__file__)
    tools_dir = os.path.dirname(here)
    manifest_path = os.path.join(tools_dir, "patch-manifest.json")
    if not os.path.isfile(manifest_path):
        print("补丁包不完整：缺少 patch-manifest.json。")
        return 1
    with open(manifest_path, "r", encoding="utf-8-sig") as f:
        manifest = json.load(f)
    entries = manifest.get("files") or []

    root = find_project_root(tools_dir) or find_project_root(os.getcwd())
    if not root:
        print("没有找到 BeefTV 项目根目录（需要能看到 backend、web、plugin-packages 文件夹）。")
        print("请把补丁包解压到项目根目录后再双击；或先进入项目根目录再运行本脚本。")
        print("当前脚本：" + here)
        return 1

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    print("=" * 52)
    print(" BeefTV 土豆协议补丁")
    print("=" * 52)
    print("交流群：土豆AIQQ交流群 715943908")
    print("项目目录：" + root)
    if os.path.normcase(os.path.dirname(tools_dir)) != os.path.normcase(root):
        print("[提示] 补丁包不在项目根目录的第一层，已向上定位到项目根：" + root)
        print("       如果这不是你要打补丁的目录，请把补丁包解压到目标项目根目录后再运行。")
    print("补丁版本：" + str(manifest.get("version", "")) + "（" + str(manifest.get("createdAt", "")) + "）")
    print("文件数量：" + str(len(entries)))
    print()

    # 1) 校验补丁包内文件
    for entry in entries:
        src = os.path.join(tools_dir, entry["source"].replace("/", os.sep))
        if not os.path.isfile(src):
            print("[错误] 补丁包缺少文件：" + entry["source"])
            return 1
        if sha256_file(src) != entry["sha256"]:
            print("[错误] 补丁文件校验失败（文件可能损坏）：" + entry["source"])
            return 1
    print("补丁文件校验通过。")

    # 2) 只备份"确实会被覆盖"的现有文件
    backup_root = os.path.join(root, ".local", "backup", stamp + "-pre-tudou-patch")
    to_change = []
    for entry in entries:
        target = os.path.join(root, entry["target"].replace("/", os.sep))
        current = sha256_file(target) if os.path.isfile(target) else ""
        if current != entry["sha256"]:
            to_change.append((entry, target, current))
    backed_up = 0
    for entry, target, current in to_change:
        if current:
            backup_file = os.path.join(backup_root, entry["target"].replace("/", os.sep))
            os.makedirs(os.path.dirname(backup_file), exist_ok=True)
            shutil.copy2(target, backup_file)
            backed_up += 1
    if backed_up:
        print("已备份 " + str(backed_up) + " 个将被覆盖的现有文件到：")
        print("  " + backup_root)
    else:
        print("没有需要备份的现有文件（目标目录均为新增文件或已是补丁版本）。")
    print()

    # 3) 应用（逐文件覆盖，幂等）
    updated = 0
    same = len(entries) - len(to_change)
    for entry, target, _current in to_change:
        src = os.path.join(tools_dir, entry["source"].replace("/", os.sep))
        os.makedirs(os.path.dirname(target), exist_ok=True)
        shutil.copy2(src, target)
        updated += 1
        print("  [更新] " + entry["target"] + "  —— " + str(entry.get("description", "")))
    print()
    if updated == 0:
        print("补丁应用完成：全部 " + str(same) + " 个文件已经是补丁版本（无需变更）。")
    else:
        print("补丁应用完成：更新 " + str(updated) + " 个文件，" + str(same) + " 个文件原本已是补丁版本。")

    # 4) 预置土豆渠道（密钥留空）
    ensure_tudou_channel(root, stamp)

    # 5) 后续步骤
    print()
    print("-" * 52)
    print("后续步骤（第 1 步必须做，Go 代码才会生效）：")
    print("  1) 重启后端（也可直接双击项目根目录的 一键启动BeefTV.bat）：")
    print("       cd " + os.path.join(root, "backend"))
    print('       $env:CANVAS_BACKEND_DATA_DIR="../.local/project-workbench-debug"   (Windows PowerShell)')
    print("       go run ./cmd/server")
    print("  2) 前端：开发服务器会自动热更新，打开着的画布页面刷新一次即可。")
    print("  3) 打开 设置 -> 渠道：找到「土豆API」，粘贴你的 API Key 并保存。")
    print("  4) 可选自检：cd backend 后执行  go test ./...")
    print()
    print("已释放到项目根目录：一键启动BeefTV.bat（双击即启动前后端并打开浏览器）。")
    print("如需回滚：双击补丁文件夹里的 一键还原BeefTV补丁.bat（会还原到打补丁前的状态；")
    print("          渠道配置属于运行数据，不会被还原脚本删除，需要时请在应用内手动删除）。")
    print()
    print("=" * 52)
    print("欢迎加入交流：土豆AIQQ交流群 715943908")
    print("入群验证暗号：土豆土豆我是地瓜我是地瓜")
    print("（使用问题、补丁反馈、AI 影视与短剧创作交流都欢迎）")
    print("=" * 52)
    print("-" * 52)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(1)
    except Exception as exc:
        print("补丁失败：" + str(exc))
        raise SystemExit(1)
