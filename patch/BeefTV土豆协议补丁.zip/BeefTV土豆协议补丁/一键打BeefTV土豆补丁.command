#!/bin/bash
cd "$(dirname "$0")"
chmod +x "$0" 2>/dev/null
xattr -d com.apple.quarantine "$0" 2>/dev/null

PY="python3"
if [ -x "../python/bin/python3" ]; then
  PY="../python/bin/python3"
fi

SCRIPT="./apply_beef_tudou_patch.py"
MANIFEST="./patch-manifest.json"

if [ ! -f "$SCRIPT" ] || [ ! -f "$MANIFEST" ]; then
  echo "[ERROR] Missing patch files in this folder."
  echo "Current folder: $(pwd)"
  echo
  read -r -p "Press Enter to close..."
  exit 1
fi

echo "Applying BeefTV Tudou patch..."
echo "After success, you can delete this folder."
echo
"$PY" "$SCRIPT"
ERR=$?
echo
if [ "$ERR" != "0" ]; then
  echo "[ERROR] Patch failed, code $ERR"
else
  echo "[OK] Patch applied."
  echo "Restart the backend to take effect, then refresh the canvas page."
fi
echo
read -r -p "Press Enter to close..."
exit $ERR
