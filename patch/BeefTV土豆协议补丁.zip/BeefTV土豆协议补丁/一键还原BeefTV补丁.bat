@echo off
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

set "SCRIPT=%~dp0restore_beef_tudou_patch.py"
if not exist "%SCRIPT%" goto MISS

where py >nul 2>nul
if %errorlevel%==0 (set "PYEXE=py -3") else (set "PYEXE=python")

echo Restoring BeefTV Tudou patch...
echo.
%PYEXE% "%SCRIPT%" %*
set "ERR=%ERRORLEVEL%"
echo.
if not "%ERR%"=="0" (
  echo [ERROR] Restore failed, code %ERR%
) else (
  echo [OK] Restore finished.
  echo Restart the backend to take effect.
)
echo.
pause
exit /b %ERR%

:MISS
echo [ERROR] Missing restore_beef_tudou_patch.py in this folder.
echo Current folder: %CD%
echo.
pause
exit /b 1
