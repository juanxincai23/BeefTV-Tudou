#!/bin/bash
cd "$(dirname "$0")"
chmod +x "$0" 2>/dev/null
xattr -d com.apple.quarantine "$0" 2>/dev/null

SCRIPT="./restore_beef_tudou_patch.py"
if [ ! -f "$SCRIPT" ]; then
  echo "[ERROR] Missing restore_beef_tudou_patch.py in this folder."
  read -r -p "Press Enter to close..."
  exit 1
fi

PY="python3"
if [ -x "../python/bin/python3" ]; then
  PY="../python/bin/python3"
fi

echo "Restoring BeefTV Tudou patch..."
echo
"$PY" "$SCRIPT" "$@"
ERR=$?
echo
if [ "$ERR" != "0" ]; then
  echo "[ERROR] Restore failed, code $ERR"
else
  echo "[OK] Restore finished."
fi
echo
read -r -p "Press Enter to close..."
exit $ERR
